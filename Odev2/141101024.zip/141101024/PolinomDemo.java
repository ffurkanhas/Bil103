class PolinomDemo{
	public static void main(String args[]){
		Polinom islem = new Polinom();
		islem.girdiOku();
		islem.turevNoktasiAl();
		System.out.println(islem.turevHesapla());
	}
}