class SaatDemo{

	public static void main(String args[]){
		Saat saat = new Saat(59,59,23);
		saat.arttir();
		System.out.println(saat.toString());
		saat.arttir();
		System.out.println(saat.toString());
		saat.arttir();
		System.out.println(saat.toString());
		saat.arttir();
		System.out.println(saat.toString());
	}
}